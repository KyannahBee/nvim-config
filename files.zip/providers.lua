-- providers.lua
-- Place this in your lua/plugins/ directory alongside the others.
--
-- Disables providers you don't use so :checkhealth stays clean.
-- A clean checkhealth means real problems stand out instead of drowning
-- in noise from perl/ruby warnings you'll never fix.
--
-- This is NOT a lazy.nvim plugin spec — it's a plain lua file.
-- Load it from your init.lua with: require("providers")
-- OR just put these lines directly in your init.lua.

vim.g.loaded_perl_provider = 0   -- you don't use perl plugins
vim.g.loaded_ruby_provider = 0   -- you don't use ruby plugins (gem install neovim is optional)

-- For python: install pynvim so the provider works properly
-- Run: pip install pynvim --break-system-packages
-- (some plugins like vim-ultest need it; harmless to have)

-- For node: install the neovim npm package
-- Run: npm install -g neovim
