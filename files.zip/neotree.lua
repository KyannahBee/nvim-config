return {
    "nvim-neo-tree/neo-tree.nvim",
    branch = "v3.x",
    dependencies = {
        "nvim-lua/plenary.nvim",
        "nvim-tree/nvim-web-devicons",
        "MunifTanjim/nui.nvim",
    },
    -- Lazy load on keymap — no reason to load the file tree at startup
    keys = {
        { "<C-n>", "<cmd>Neotree filesystem reveal left toggle<cr>",
          desc = "Toggle File Tree", noremap = true, silent = true },
    },
    config = function()
        require("neo-tree").setup({
            close_if_last_window = true, -- don't leave an orphan neotree window
            filesystem = {
                follow_current_file = {
                    enabled = true, -- highlight current file in tree
                },
                filtered_items = {
                    visible = false,
                    hide_dotfiles = false, -- show dotfiles (useful for config work)
                    hide_gitignored = true,
                },
            },
        })
    end,
}
