return {
    "folke/lazydev.nvim",
    ft = "lua",
    opts = {
        library = {
            { path = "${3rd}/luvit-meta/library", words = { "vim%.uv" } },
            -- Load nvim-dap types when dap is referenced
            { path = "nvim-dap", words = { "dap" } },
        },
    },
}
