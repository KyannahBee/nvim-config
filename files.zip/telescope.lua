-- Merged from telescope.lua + telescope-keys.lua
-- Having two files both configuring telescope caused double setup() calls
-- and duplicate keymaps. One file, one setup.
return {
    {
        "nvim-telescope/telescope.nvim",
        -- Removed tag = '0.1.8' pin — let lazy.nvim track latest stable.
        -- Pinning to a specific tag on a rolling release means you won't get
        -- bug fixes unless you manually bump it.
        dependencies = {
            "nvim-lua/plenary.nvim",
            "nvim-telescope/telescope-ui-select.nvim",
        },
        config = function()
            local telescope = require("telescope")
            local builtin   = require("telescope.builtin")

            telescope.setup({
                defaults = {
                    -- Useful on a laptop: fuzzy find ignores case
                    sorting_strategy = "ascending",
                    layout_config = { prompt_position = "top" },
                },
                extensions = {
                    ["ui-select"] = {
                        require("telescope.themes").get_dropdown(),
                    },
                },
            })

            telescope.load_extension("ui-select")

            -- File/project navigation
            vim.keymap.set("n", "<leader>ff", builtin.find_files,  { desc = "Find Files" })
            vim.keymap.set("n", "<leader>fg", builtin.live_grep,   { desc = "Live Grep" })
            vim.keymap.set("n", "<leader>fb", builtin.buffers,     { desc = "Buffers" })
            vim.keymap.set("n", "<leader>fh", builtin.help_tags,   { desc = "Help Tags" })
            vim.keymap.set("n", "<leader>pf", builtin.find_files,  { desc = "Find Files (alt)" })
            vim.keymap.set("n", "<C-p>",      builtin.git_files,   { desc = "Git Files" })
            vim.keymap.set("n", "<leader>vh", builtin.help_tags,   { desc = "Help Tags (alt)" })
            vim.keymap.set("n", "<leader>ps", function()
                builtin.grep_string({ search = vim.fn.input("Grep > ") })
            end, { desc = "Search String" })
        end,
    },
}
