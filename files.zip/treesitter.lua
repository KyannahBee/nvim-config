return {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate",
    lazy = false,
    -- Ensure treesitter loads before anything that might trigger filetype detection
    priority = 100,
    config = function()
        local status_ok, configs = pcall(require, "nvim-treesitter.configs")
        if not status_ok then
            vim.notify("nvim-treesitter not found", vim.log.levels.WARN)
            return
        end

        configs.setup({
            ensure_installed = {
                "lua", "python", "javascript", "typescript",
                "c", "cpp", "java", "rust", "html", "css", "bash",
                "vim", "vimdoc", "query",
            },
            -- Install missing parsers synchronously on first open
            sync_install = false,
            auto_install = true,
            highlight = {
                enable = true,
                -- Disable for very large files where it becomes slow
                disable = function(_, buf)
                    local max_filesize = 200 * 1024 -- 200 KB
                    local ok, stats = pcall(vim.loop.fs_stat, vim.api.nvim_buf_get_name(buf))
                    if ok and stats and stats.size > max_filesize then
                        return true
                    end
                end,
            },
            indent = { enable = true },
        })

        -- Force nvim-treesitter's parsers to take precedence over system parsers.
        -- This is the key fix for the duplicate lua/c parser conflict you saw in :checkhealth.
        -- System parsers live in /usr/share/nvim/runtime/parser/ and can be mismatched
        -- with Neovim's bundled queries on a rolling release like EndeavourOS.
        vim.treesitter.language.register("lua", "lua")
    end,
}
