return {
    {
        "neovim/nvim-lspconfig",
        dependencies = {
            "williamboman/mason.nvim",
            "williamboman/mason-lspconfig.nvim",
            "hrsh7th/cmp-nvim-lsp",
            "folke/lazydev.nvim", -- declared here as dep, but setup lives in lazydev.lua
        },
        config = function()
            -- Mason setup
            require("mason").setup()
            require("mason-lspconfig").setup({
                ensure_installed = {
                    "lua_ls", "pyright", "ts_ls", "html", "cssls",
                    "clangd", "bashls", "rust_analyzer", "jdtls",
                },
                -- Automatically install servers that are configured below
                automatic_installation = true,
            })

            local capabilities = require("cmp_nvim_lsp").default_capabilities()

            -- Standard servers with no special config
            local servers = {
                "pyright", "ts_ls", "html", "cssls",
                "clangd", "bashls", "rust_analyzer", "jdtls",
            }

            for _, server in ipairs(servers) do
                vim.lsp.config(server, { capabilities = capabilities })
                vim.lsp.enable(server)
            end

            -- lua_ls needs special treatment to understand the vim global
            -- and to not spam warnings about your entire Neovim config
            vim.lsp.config("lua_ls", {
                capabilities = capabilities,
                settings = {
                    Lua = {
                        diagnostics = { globals = { "vim" } },
                        workspace = { checkThirdParty = false },
                        hint = { enable = true },
                        codeLens = { enable = true },
                    },
                },
            })
            vim.lsp.enable("lua_ls")

            -- LSP keybindings on attach
            vim.api.nvim_create_autocmd("LspAttach", {
                group = vim.api.nvim_create_augroup("UserLspAttach", { clear = true }),
                callback = function(args)
                    local opts = { buffer = args.buf, noremap = true, silent = true }
                    vim.keymap.set("n", "gd",         vim.lsp.buf.definition,    opts)
                    vim.keymap.set("n", "gD",         vim.lsp.buf.declaration,   opts)
                    vim.keymap.set("n", "gi",         vim.lsp.buf.implementation,opts)
                    vim.keymap.set("n", "K",          vim.lsp.buf.hover,         opts)
                    vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename,        opts)
                    vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action,   opts)
                    vim.keymap.set("n", "gr",         vim.lsp.buf.references,    opts)
                    vim.keymap.set("n", "<leader>f",  function()
                        vim.lsp.buf.format({ async = true })
                    end, opts)
                    -- Diagnostic navigation
                    vim.keymap.set("n", "[d", vim.diagnostic.goto_prev, opts)
                    vim.keymap.set("n", "]d", vim.diagnostic.goto_next, opts)
                    vim.keymap.set("n", "<leader>d", vim.diagnostic.open_float, opts)
                end,
            })

            -- Nicer diagnostic signs
            vim.diagnostic.config({
                virtual_text = true,
                signs = true,
                underline = true,
                update_in_insert = false, -- don't distract while typing
                severity_sort = true,
            })
        end,
    },

    -- Completion engine
    {
        "hrsh7th/nvim-cmp",
        dependencies = {
            "L3MON4D3/LuaSnip",
            "saadparwaiz1/cmp_luasnip",
            "hrsh7th/cmp-buffer",
            "hrsh7th/cmp-path",
            "hrsh7th/cmp-nvim-lsp",
        },
        config = function()
            local cmp = require("cmp")
            local luasnip = require("luasnip")

            cmp.setup({
                snippet = {
                    expand = function(args) luasnip.lsp_expand(args.body) end,
                },
                mapping = cmp.mapping.preset.insert({
                    ["<C-Space>"] = cmp.mapping.complete(),
                    ["<C-e>"]     = cmp.mapping.abort(),
                    ["<CR>"]      = cmp.mapping.confirm({ select = true }),
                    ["<C-d>"]     = cmp.mapping.scroll_docs(4),
                    ["<C-u>"]     = cmp.mapping.scroll_docs(-4),
                    ["<Tab>"]     = cmp.mapping(function(fallback)
                        if cmp.visible() then
                            cmp.select_next_item()
                        elseif luasnip.expand_or_jumpable() then
                            luasnip.expand_or_jump()
                        else
                            fallback()
                        end
                    end, { "i", "s" }),
                    ["<S-Tab>"]   = cmp.mapping(function(fallback)
                        if cmp.visible() then
                            cmp.select_prev_item()
                        elseif luasnip.jumpable(-1) then
                            luasnip.jump(-1)
                        else
                            fallback()
                        end
                    end, { "i", "s" }),
                }),
                sources = cmp.config.sources({
                    { name = "nvim_lsp", priority = 1000 },
                    { name = "luasnip",  priority = 750 },
                    { name = "buffer",   priority = 500 },
                    { name = "path",     priority = 250 },
                }),
                -- Show source name in completion menu
                formatting = {
                    format = function(entry, item)
                        local source_names = {
                            nvim_lsp = "[LSP]",
                            luasnip  = "[Snip]",
                            buffer   = "[Buf]",
                            path     = "[Path]",
                        }
                        item.menu = source_names[entry.source.name] or ""
                        return item
                    end,
                },
            })
        end,
    },
}
