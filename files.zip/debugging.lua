return {
    "mfussenegger/nvim-dap",
    dependencies = {
        "rcarriga/nvim-dap-ui",
        "nvim-neotest/nvim-nio",
    },
    config = function()
        local dap    = require("dap")
        local dapui  = require("dapui")

        -- This was missing — without it dapui has no layout and silently fails
        dapui.setup()

        -- Auto open/close UI with debug sessions
        dap.listeners.before.attach.dapui_config           = function() dapui.open() end
        dap.listeners.before.launch.dapui_config           = function() dapui.open() end
        dap.listeners.before.event_terminated.dapui_config = function() dapui.close() end
        dap.listeners.before.event_exited.dapui_config     = function() dapui.close() end

        -- Keymaps
        local opts = { noremap = true, silent = true }
        vim.keymap.set("n", "<Leader>db", dap.toggle_breakpoint,          opts)
        vim.keymap.set("n", "<Leader>dc", dap.continue,                   opts)
        vim.keymap.set("n", "<Leader>do", dap.step_over,                  opts)
        vim.keymap.set("n", "<Leader>di", dap.step_into,                  opts)
        vim.keymap.set("n", "<Leader>dO", dap.step_out,                   opts)
        vim.keymap.set("n", "<Leader>du", function() dapui.toggle() end,  opts)
        vim.keymap.set("n", "<Leader>dr", function() dap.repl.open() end, opts)
    end,
}
